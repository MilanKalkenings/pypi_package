a small PyPI package that implements basic functionalities needed in a wide range of deep learning projects.
